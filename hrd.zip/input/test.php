<?php
	require_once("../user/auth.php"); 
	require_once("../config.php");

if(isset($_POST['savefoto'])) {
  $idnk = $_POST['idnk'];
  $nfoto = $_FILES['foto']['name'];
  if ($nfoto=="") {
  	?>
  	<script>alert('File foto tidak boleh kosong');location.replace('view.php?id='+<?php echo $idnk; ?>);</script>
  	<?php
  }
}
	?>